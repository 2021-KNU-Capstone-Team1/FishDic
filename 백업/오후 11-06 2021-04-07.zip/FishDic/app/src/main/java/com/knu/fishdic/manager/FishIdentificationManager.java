package com.knu.fishdic.manager;

// 물고기 판별 관리를 위한 FishIdentificationManager 정의

public class FishIdentificationManager {
}
