package com.knu.fishdic;

import android.app.Activity;

// 도감 화면 액티비티 정의

public class DicActivity extends Activity {
}
