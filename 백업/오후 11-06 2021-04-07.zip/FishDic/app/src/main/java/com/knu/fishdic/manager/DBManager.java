package com.knu.fishdic.manager;

// 이달의 금어기, 도감관련 모든 기능을 위한 DBManager 정의

public class DBManager {
}
