package com.knu.fishdic;

import android.app.Activity;

// 어류 상세정보 화면 액티비티 정의

public class FishDetailActivity extends Activity {
}
