package com.knu.fishdic;

import android.app.Activity;

// 이달의 금어기 화면 액티비티 정의

public class DeniedFishActivity extends Activity {
}
